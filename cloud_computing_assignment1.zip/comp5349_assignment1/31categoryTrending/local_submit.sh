#!/bin/bash

spark-submit \
    --master local[2] \
    category.py
